import json
# from ncf.process import rec
from rest_framework.views import APIView
from rest_framework.response import Response


class Predict(APIView):
    def post(self, request):
        data = request.data

        #test
        movie_ids = json.loads(data['movies'])
        ratings = json.loads(data['ratings'])

        # top5 = "hello"
        # response = rec(movie_ids, ratings)
        # if response == "No items":
        #     response_dict = {"response": "không có phim trong db"}
        #     return Response(response_dict, status=200)
        # else:
        #     response_dict = {"predict": response}
        #     return Response(response_dict, status=200)