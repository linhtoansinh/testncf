import sys
import pandas as pd
# import tensorflow as tf
# tf.get_logger().setLevel('ERROR') # only show error messages

from recommenders.utils.timer import Timer
from recommenders.models.ncf.ncf_singlenode import NCF
from recommenders.models.ncf.dataset import Dataset as NCFDataset
from recommenders.datasets import movielens
from recommenders.utils.notebook_utils import is_jupyter
from recommenders.datasets.python_splitters import python_chrono_split
from recommenders.evaluation.python_evaluation import (rmse, mae, rsquared, exp_var, map_at_k, ndcg_at_k, precision_at_k, 
                                                     recall_at_k, get_top_k_items)


def rec(item, rating):
    # top k items to recommend
    TOP_K = 10

    # Select MovieLens data size: 100k, 1m, 10m, or 20m
    MOVIELENS_DATA_SIZE = '100k'

    # Model parameters
    EPOCHS = 50
    BATCH_SIZE = 256

    SEED = 42


    df = movielens.load_pandas_df(
        size=MOVIELENS_DATA_SIZE,
        header=["userID", "itemID", "rating", "timestamp"]
    )


    train, test = python_chrono_split(df, 0.75)

    input_items = []
    for item in items:
        if item in train["itemID"]:
            input_items.append(item)
    if len(input_items) == 0:
        return "No items"


    #add new user to train
    user = 944
    # item = [168,166,739,27]
    # rating = [5] * len(item)
    timestamp = range(len(item))
    user = [user] * len(item) 

    users, items, ratings, timestamps = [], [], [], []
    users.extend(user)
    items.extend(item)
    ratings.extend(rating)
    timestamps.extend(timestamp)

    new_data = pd.DataFrame(data={"userID": users, "itemID":items, "rating":ratings, "timestamp": timestamps})
    train = train.append(new_data, ignore_index = True)

    test = test[test["userID"].isin(train["userID"].unique())]
    test = test[test["itemID"].isin(train["itemID"].unique())]

    #train test to csv
    train_file = "./train.csv"
    test_file = "./test.csv"
    train.to_csv(train_file, index=False)
    test.to_csv(test_file, index=False)

    #load ncf data format
    data = NCFDataset(train_file=train_file, test_file=test_file, seed=SEED)

    #initial model
    model = NCF (
        n_users=data.n_users, 
        n_items=data.n_items,
        model_type="NeuMF",
        n_factors=4,
        layer_sizes=[16,8,4],
        n_epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        learning_rate=1e-3,
        verbose=10,
        seed=SEED
    )

    #train
    with Timer() as train_time:
        model.fit(data)
    print("Took {} seconds for training.".format(train_time))

    #predict
    items = list(train.itemID.unique())
    users = [user] * len(item)
    preds = list(model.predict(user, item, is_list=True))

    all_predictions = pd.DataFrame(data={"userID": users, "itemID":items, "prediction":preds})
    top = all_predictions.sort_values(by='prediction', ascending=False).iloc[:5]["itemID"]
    return top

